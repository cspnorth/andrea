<div class="notification <?php echo implode(", ", (array)$atts['type']); ?>">
	<div class="icon">
		<?php if(isset($content)){ echo $content;} ?>
	</div>
</div>