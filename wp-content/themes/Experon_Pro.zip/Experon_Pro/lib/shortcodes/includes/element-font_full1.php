<?php
$title       = NULL;
$link        = NULL;
$button      = NULL;
$icon        = NULL;
$size        = NULL; 
$color       = NULL;
$background  = NULL;
$spin        = NULL;

$link_start  = NULL;
$link_end    = NULL; 
$link_class  = NULL;
$link_icon   = NULL;

$title       = $atts['title'];
$link        = $atts['link'];
$button      = $atts['button'];
$icon        = $atts['icon'];
$size        = $atts['size'];
$color       = $atts['color'];
$background  = $atts['background'];
$spin        = $atts['spin'];


if ( empty( $icon )  ) {
	$icon = 'fa fa-file';
} else {
	$icon = 'fa fa-' . $icon;
}
if ( empty( $size ) or $size == 'small' ) {
	$size = ' fa-lg';
} else if ( $size == 'medium' ) {
	$size = ' fa-2x';
} else if ( $size == 'large' ) {
	$size = ' fa-3x';
} else if ( $size == 'extra large' ) {
	$size = ' fa-4x';
}
if ( ! empty( $background ) ) {
	$background_class = ' iconbackground';
	$background_color = ' style="background: ' . $background . ';"';
} else {
	$background_class = NULL;
	$background_color = NULL;
}
if ( $color == 'light' ) {
	$color = ' fa-inverse';
} else {
	$color = '';
}
if ( $spin == 'on' ) {
	$spin = ' fa-spin';
} else {
	$spin = '';
}
if ( ! empty( $title ) ) {
	$title = '<h3>' . $title. '</h3>';
} else {
	$title = '';
}
if ( ! empty( $link ) ) {
	if ( ! empty( $button ) ) {
		$link_class = ' iconlink';
		$link_icon  = '<p class="iconurl"><a href="' . $link . '">' . $button . '</a></p>';
	}
	$link_start = '<a href="' . $link . '">';
	$link_end   = '</a>';
}

echo     '<div class="iconfull style1' . $link_class .  $background_class . '"' . $background_color . '>',
		     '<div class="iconimage">',
			     $link_start . '<i class="' . $icon . $size . $spin . $color .'"></i>' . $link_end,
		     '</div>',
	    	 '<div class="iconmain">',
				 $title,
	    		 '<p>' . $content . '</p>',
				 $link_icon,
	    	 '</div>',
	     '</div>';


?>