<?php
/**
*
* fieldgroups for thinkupshortcodes/tabs2
*
* @package Thinkupshortcodes
* @author Think Up Themes Ltd contact@thinkupthemes.com
* @license GPL-2.0+
* @link www.thinkupthemes.com
* @copyright 2017 Think Up Themes Ltd
*/


$configfiles = array(
	self::get_path( __FILE__ ) . 'tabs2-title.php', 
	self::get_path( __FILE__ ) . 'tabs2-toggle-buttons.php', 
);

