<?php
/**
*
* fieldgroups for thinkupshortcodes/youtube
*
* @package Thinkupshortcodes
* @author Think Up Themes Ltd contact@thinkupthemes.com
* @license GPL-2.0+
* @link www.thinkupthemes.com
* @copyright 2017 Think Up Themes Ltd
*/


$configfiles = array(
	self::get_path( __FILE__ ) . 'youtube-general-settings.php', 
);

