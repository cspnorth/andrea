<?php
/**
*
* fieldgroups for thinkupshortcodes/thinkup_builder_pricingtable
*
* @package Thinkupshortcodes
* @author Think Up Themes Ltd contact@thinkupthemes.com
* @license GPL-2.0+
* @link www.thinkupthemes.com
* @copyright 2017 Think Up Themes Ltd
*/


$configfiles = array(
	self::get_path( __FILE__ ) . 'thinkup_builder_pricingtable-package.php', 
	self::get_path( __FILE__ ) . 'thinkup_builder_pricingtable-pricing-items.php', 
);

